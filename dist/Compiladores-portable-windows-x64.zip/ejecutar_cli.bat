@echo off
cd /d "%~dp0"
"%~dp0compilador_lp.exe" %*
pause
